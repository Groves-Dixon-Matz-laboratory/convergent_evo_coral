#species_tree
#This directory contains the inputs, commands, and results for
#building the species tree using RAxML
